#import "MainWindowController.h"
#include <string>

static NSString * const kGitHubLatestReleaseAPI =
    @"https://api.github.com/repos/apple/container/releases/latest";

static NSDictionary<NSString *, NSString *> *imageIDMap() {
    return @{
        @"Ubuntu (Latest)"        : @"ubuntu:latest",
        @"Ubuntu 22.04 LTS"       : @"ubuntu:22.04",
        @"Ubuntu 20.04 LTS"       : @"ubuntu:20.04",
        @"Debian (Latest)"        : @"debian:latest",
        @"Alpine Linux (Minimal)" : @"alpine:latest",
        @"Fedora (Latest)"        : @"fedora:latest",
        @"Arch Linux (Latest)"    : @"archlinux:latest",
        @"CentOS Stream 9"        : @"centos:stream9",
    };
}

static NSArray<NSString *> *imageOrder() {
    return @[
        @"Ubuntu (Latest)",
        @"Ubuntu 22.04 LTS",
        @"Ubuntu 20.04 LTS",
        @"Debian (Latest)",
        @"Alpine Linux (Minimal)",
        @"Fedora (Latest)",
        @"Arch Linux (Latest)",
        @"CentOS Stream 9",
    ];
}

static NSDictionary<NSString *, NSString *> *imageDescriptions() {
    return @{
        @"Ubuntu (Latest)"        : @"",
        @"Ubuntu 22.04 LTS"       : @"(Long-Term-Support Release)",
        @"Ubuntu 20.04 LTS"       : @"(Long-Term-Support Release)",
        @"Debian (Latest)"        : @"",
        @"Alpine Linux (Minimal)" : @"",
        @"Fedora (Latest)"        : @"",
        @"Arch Linux (Latest)"    : @"",
        @"CentOS Stream 9"        : @"",
    };
}

static NSDictionary<NSString *, NSString *> *shellIDMap() {
    return @{
        @"Bash" : @"/bin/bash",
        @"sh"   : @"/bin/sh",
    };
}

static NSArray<NSString *> *shellOrder() {
    return @[ @"Bash", @"sh" ];
}

static NSDictionary<NSString *, NSString *> *shellDescriptions() {
    return @{
        @"Bash" : @"Most common shell for Linux.",
        @"sh"   : @"Minimal POSIX shell with large scale compatibility.",
    };
}

@interface MainWindowController ()

@property (nonatomic, strong) NSPopUpButton       *imagePopup;
@property (nonatomic, strong) NSPopUpButton       *shellPopup;
@property (nonatomic, strong) NSTextField         *customImageField;
@property (nonatomic, strong) NSButton            *customImageToggle;
@property (nonatomic, strong) NSTextField         *shellDescLabel;
@property (nonatomic, strong) NSTextField         *statusLabel;
@property (nonatomic, strong) NSProgressIndicator *spinner;
@property (nonatomic, strong) NSButton            *pullButton;
@property (nonatomic, strong) NSButton            *launchButton;
@property (nonatomic, assign) BOOL                 usingCustomImage;

@property (nonatomic, strong) NSView              *installBanner;
@property (nonatomic, strong) NSTextField         *installTitleLabel;
@property (nonatomic, strong) NSTextField         *installBodyLabel;
@property (nonatomic, strong) NSButton            *downloadButton;
@property (nonatomic, strong) NSButton            *recheckButton;
@property (nonatomic, strong) NSProgressIndicator *downloadSpinner;
@property (nonatomic, strong) NSTextField         *downloadStatusLabel;
@property (nonatomic, strong) NSTimer             *installCheckTimer;

// System-not-running banner
@property (nonatomic, strong) NSView              *systemBanner;
@property (nonatomic, strong) NSTextField         *systemTitleLabel;
@property (nonatomic, strong) NSTextField         *systemBodyLabel;
@property (nonatomic, strong) NSButton            *startSystemButton;
@property (nonatomic, strong) NSProgressIndicator *startSystemSpinner;
@property (nonatomic, strong) NSTextField         *startSystemStatusLabel;
@property (nonatomic, strong) NSButton            *recheckSystemButton;

- (void)buildWindow;
- (void)buildInstallBanner;
- (void)buildSystemBanner;
- (void)buildMenu;
- (void)checkContainerInstalled;
- (void)checkContainerSystemRunning;
- (void)onLaunch:(id)sender;
- (void)onPull:(id)sender;
- (void)onToggleCustomImage:(id)sender;
- (void)onImageChanged:(id)sender;
- (void)onShellChanged:(id)sender;
- (void)onDownloadInstaller:(id)sender;
- (void)onRecheckInstall:(id)sender;
- (void)onStartSystem:(id)sender;
- (void)onRecheckSystem:(id)sender;
- (void)fetchLatestReleaseAndDownload;
- (void)downloadPkgFromURL:(NSURL *)pkgURL version:(NSString *)version;
- (void)downloadFailed:(NSString *)reason;
- (void)startInstallWatcher;
- (void)stopInstallWatcher;
- (void)installWatcherTick:(NSTimer *)timer;
- (void)runContainerCLI:(NSArray<NSString *> *)args
            completion:(void(^)(BOOL success, NSString *output))completion;
- (NSString *)containerCLIPath;
- (BOOL)isContainerInstalled;
- (void)setStatus:(NSString *)msg isError:(BOOL)error;
- (void)setDownloadStatus:(NSString *)msg isError:(BOOL)error;
- (void)setStartSystemStatus:(NSString *)msg isError:(BOOL)error;
- (NSString *)resolvedImageName;
- (NSString *)resolvedShellPath;
- (void)updateShellDescription;
- (void)checkImageDownloaded;
- (void)setButton:(NSButton *)button text:(NSString *)text;
- (void)setMainUIEnabled:(BOOL)enabled;
- (void)showAboutPanel:(id)sender;

@end

@implementation MainWindowController

- (instancetype)init {
    NSRect frame = NSMakeRect(0, 0, 460, 400);
    NSWindowStyleMask style = NSWindowStyleMaskTitled
                            | NSWindowStyleMaskClosable
                            | NSWindowStyleMaskMiniaturizable;
    NSWindow *win = [[NSWindow alloc] initWithContentRect:frame
                                               styleMask:style
                                                 backing:NSBackingStoreBuffered
                                                   defer:NO];
    win.title              = @"Container Launcher";
    win.releasedWhenClosed = NO;

    NSVisualEffectView *vev = [[NSVisualEffectView alloc] initWithFrame:frame];
    vev.material     = NSVisualEffectMaterialSidebar;
    vev.blendingMode = NSVisualEffectBlendingModeBehindWindow;
    vev.state        = NSVisualEffectStateActive;
    win.contentView  = vev;

    [win center];
    self = [super initWithWindow:win];
    if (self) {
        _usingCustomImage = NO;
        [self buildWindow];
        [self buildInstallBanner];
        [self buildSystemBanner];
        [self buildMenu];
        [self checkContainerInstalled];
    }
    return self;
}

- (void)buildWindow {
    NSView *cv  = self.window.contentView;
    CGFloat W   = 460;
    CGFloat pad = 20;
    CGFloat cw  = W - pad * 2;

    NSTextField *appTitle = [NSTextField labelWithString:@"Container Launcher"];
    appTitle.frame     = NSMakeRect(pad, 362, 280, 20);
    appTitle.font      = [NSFont systemFontOfSize:15 weight:NSFontWeightSemibold];
    appTitle.textColor = NSColor.labelColor;
    [cv addSubview:appTitle];

    NSTextField *appSub = [NSTextField labelWithString:@"Run Linux on your Macintosh."];
    appSub.frame     = NSMakeRect(pad, 346, 280, 16);
    appSub.font      = [NSFont systemFontOfSize:12];
    appSub.textColor = NSColor.secondaryLabelColor;
    [cv addSubview:appSub];

    NSBox *sep0 = [[NSBox alloc] initWithFrame:NSMakeRect(0, 334, W, 1)];
    sep0.boxType = NSBoxSeparator;
    [cv addSubview:sep0];

    NSTextField *label1 = [NSTextField labelWithString:@"Choose your Linux system:"];
    label1.frame     = NSMakeRect(pad, 314, cw, 14);
    label1.font      = [NSFont systemFontOfSize:10 weight:NSFontWeightSemibold];
    label1.textColor = NSColor.tertiaryLabelColor;
    [cv addSubview:label1];

    self.imagePopup = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(pad, 284, cw, 26) pullsDown:NO];
    self.imagePopup.bezelStyle = NSBezelStyleRounded;
    self.imagePopup.font       = [NSFont systemFontOfSize:13];
    for (NSString *name in imageOrder()) {
        [self.imagePopup addItemWithTitle:name];
    }
    [self.imagePopup selectItemAtIndex:0];
    [self.imagePopup setTarget:self];
    [self.imagePopup setAction:@selector(onImageChanged:)];
    [cv addSubview:self.imagePopup];

    self.customImageField = [[NSTextField alloc] initWithFrame:NSMakeRect(pad, 284, cw, 26)];
    self.customImageField.placeholderString = @"e.g. nginx:latest  or  myrepo/myimage:tag";
    self.customImageField.font              = [NSFont systemFontOfSize:13];
    self.customImageField.hidden            = YES;
    [cv addSubview:self.customImageField];

    self.customImageToggle = [NSButton checkboxWithTitle:@"Use a custom image"
                                                  target:self
                                                  action:@selector(onToggleCustomImage:)];
    self.customImageToggle.frame = NSMakeRect(pad, 258, cw, 18);
    self.customImageToggle.font  = [NSFont systemFontOfSize:12];
    [cv addSubview:self.customImageToggle];

    NSBox *sep1 = [[NSBox alloc] initWithFrame:NSMakeRect(pad, 244, cw, 1)];
    sep1.boxType = NSBoxSeparator;
    [cv addSubview:sep1];

    NSTextField *label2 = [NSTextField labelWithString:@"Choose a shell environment:"];
    label2.frame     = NSMakeRect(pad, 208, cw, 14);
    label2.font      = [NSFont systemFontOfSize:10 weight:NSFontWeightSemibold];
    label2.textColor = NSColor.tertiaryLabelColor;
    [cv addSubview:label2];

    self.shellPopup = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(pad, 178, 220, 26) pullsDown:NO];
    self.shellPopup.bezelStyle = NSBezelStyleRounded;
    self.shellPopup.font       = [NSFont systemFontOfSize:13];
    for (NSString *name in shellOrder()) {
        [self.shellPopup addItemWithTitle:name];
    }
    [self.shellPopup selectItemAtIndex:0];
    [self.shellPopup setTarget:self];
    [self.shellPopup setAction:@selector(onShellChanged:)];
    [cv addSubview:self.shellPopup];

    self.shellDescLabel = [NSTextField labelWithString:@""];
    self.shellDescLabel.frame     = NSMakeRect(pad, 158, cw, 16);
    self.shellDescLabel.font      = [NSFont systemFontOfSize:12];
    self.shellDescLabel.textColor = NSColor.secondaryLabelColor;
    [cv addSubview:self.shellDescLabel];
    [self updateShellDescription];

    NSBox *sep2 = [[NSBox alloc] initWithFrame:NSMakeRect(pad, 144, cw, 1)];
    sep2.boxType = NSBoxSeparator;
    [cv addSubview:sep2];

    CGFloat btnH = 30;
    CGFloat btnW = 150;

    self.pullButton = [NSButton buttonWithTitle:@"" target:self action:@selector(onPull:)];
    self.pullButton.frame      = NSMakeRect((W - btnW) / 2.0, 86, btnW, btnH);
    self.pullButton.bezelStyle = NSBezelStyleRounded;
    self.pullButton.toolTip    = @"Downloads the selected Linux image from the internet. (One time only)";
    [self setButton:self.pullButton text:@"Download Image"];
    [cv addSubview:self.pullButton];

    NSBox *sep4 = [[NSBox alloc] initWithFrame:NSMakeRect(0, 58, W, 1)];
    sep4.boxType = NSBoxSeparator;
    [cv addSubview:sep4];

    self.statusLabel = [NSTextField labelWithString:@"Ready"];
    self.statusLabel.frame         = NSMakeRect(pad, 18, W - pad * 3 - btnW, 22);
    self.statusLabel.font          = [NSFont systemFontOfSize:12];
    self.statusLabel.textColor     = NSColor.secondaryLabelColor;
    self.statusLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    [cv addSubview:self.statusLabel];

    self.launchButton = [NSButton buttonWithTitle:@"" target:self action:@selector(onLaunch:)];
    self.launchButton.frame         = NSMakeRect(W - pad - btnW, 14, btnW, btnH);
    self.launchButton.bezelStyle    = NSBezelStyleRounded;
    self.launchButton.keyEquivalent = @"\r";
    self.launchButton.toolTip       = @"Start the Linux environment in Terminal.";
    [self setButton:self.launchButton text:@"Open Terminal"];
    [cv addSubview:self.launchButton];

    self.spinner = [[NSProgressIndicator alloc] initWithFrame:NSMakeRect(pad + (W - pad*3 - btnW) + 4, 21, 16, 16)];
    self.spinner.style                = NSProgressIndicatorStyleSpinning;
    self.spinner.controlSize          = NSControlSizeSmall;
    self.spinner.displayedWhenStopped = NO;
    [cv addSubview:self.spinner];

    [self setStatus:@"Ready" isError:NO];
}

- (void)buildInstallBanner {
    NSView *cv = self.window.contentView;
    CGFloat W  = 460;
    CGFloat H  = 400;

    self.installBanner = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, W, H)];
    self.installBanner.wantsLayer = YES;
    self.installBanner.layer.backgroundColor =
        [NSColor.windowBackgroundColor colorWithAlphaComponent:0.88].CGColor;
    self.installBanner.hidden = YES;
    [cv addSubview:self.installBanner positioned:NSWindowAbove relativeTo:nil];

    CGFloat pad = 30;
    CGFloat cw  = W - pad * 2;

    NSImageView *iconView = [[NSImageView alloc] initWithFrame:NSMakeRect((W - 64) / 2.0, 292, 64, 64)];
    iconView.image = [NSImage imageNamed:@"AppIcon"];
    iconView.imageScaling = NSImageScaleProportionallyUpOrDown;
    [self.installBanner addSubview:iconView];

    self.installTitleLabel = [NSTextField labelWithString:@"Container is not installed"];
    self.installTitleLabel.frame     = NSMakeRect(pad, 266, cw, 22);
    self.installTitleLabel.font      = [NSFont systemFontOfSize:15 weight:NSFontWeightSemibold];
    self.installTitleLabel.textColor = NSColor.labelColor;
    self.installTitleLabel.alignment = NSTextAlignmentCenter;
    [self.installBanner addSubview:self.installTitleLabel];

    self.installBodyLabel = [NSTextField wrappingLabelWithString:
        @"Container Launcher requires Apple\u2019s container CLI.\n"
         "Click below to fetch the latest signed installer from GitHub and open it."];
    self.installBodyLabel.frame     = NSMakeRect(pad, 196, cw, 62);
    self.installBodyLabel.font      = [NSFont systemFontOfSize:12];
    self.installBodyLabel.textColor = NSColor.secondaryLabelColor;
    self.installBodyLabel.alignment = NSTextAlignmentCenter;
    [self.installBanner addSubview:self.installBodyLabel];

    self.downloadButton = [NSButton buttonWithTitle:@""
                                             target:self
                                             action:@selector(onDownloadInstaller:)];
    CGFloat dBtnW = 200;
    self.downloadButton.frame         = NSMakeRect((W - dBtnW) / 2.0, 154, dBtnW, 32);
    self.downloadButton.bezelStyle    = NSBezelStyleRounded;
    self.downloadButton.keyEquivalent = @"\r";
    [self setButton:self.downloadButton text:@"Download Installer\u2026"];
    [self.installBanner addSubview:self.downloadButton];

    self.downloadSpinner = [[NSProgressIndicator alloc]
        initWithFrame:NSMakeRect((W + dBtnW) / 2.0 + 6, 161, 16, 16)];
    self.downloadSpinner.style                = NSProgressIndicatorStyleSpinning;
    self.downloadSpinner.controlSize          = NSControlSizeSmall;
    self.downloadSpinner.displayedWhenStopped = NO;
    [self.installBanner addSubview:self.downloadSpinner];

    self.downloadStatusLabel = [NSTextField labelWithString:@""];
    self.downloadStatusLabel.frame         = NSMakeRect(pad, 126, cw, 18);
    self.downloadStatusLabel.font          = [NSFont systemFontOfSize:11];
    self.downloadStatusLabel.textColor     = NSColor.secondaryLabelColor;
    self.downloadStatusLabel.alignment     = NSTextAlignmentCenter;
    self.downloadStatusLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    [self.installBanner addSubview:self.downloadStatusLabel];

    NSBox *sep = [[NSBox alloc] initWithFrame:NSMakeRect(pad, 110, cw, 1)];
    sep.boxType = NSBoxSeparator;
    [self.installBanner addSubview:sep];

    NSTextField *alreadyNote = [NSTextField labelWithString:
        @"Already installed Container in a custom location?"];
    alreadyNote.frame     = NSMakeRect(pad, 84, cw, 16);
    alreadyNote.font      = [NSFont systemFontOfSize:11];
    alreadyNote.textColor = NSColor.tertiaryLabelColor;
    alreadyNote.alignment = NSTextAlignmentCenter;
    [self.installBanner addSubview:alreadyNote];

    self.recheckButton = [NSButton buttonWithTitle:@"Re-check Installation"
                                            target:self
                                            action:@selector(onRecheckInstall:)];
    CGFloat rBtnW = 180;
    self.recheckButton.frame      = NSMakeRect((W - rBtnW) / 2.0, 50, rBtnW, 26);
    self.recheckButton.bezelStyle = NSBezelStyleRounded;
    self.recheckButton.font       = [NSFont systemFontOfSize:12];
    [self.installBanner addSubview:self.recheckButton];
}

// ---------------------------------------------------------------------------
// System-not-running banner
// Shown (above the install banner in z-order) when container is installed
// but `container system start` has not been run yet.
// ---------------------------------------------------------------------------
- (void)buildSystemBanner {
    NSView *cv = self.window.contentView;
    CGFloat W  = 460;
    CGFloat H  = 400;

    self.systemBanner = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, W, H)];
    self.systemBanner.wantsLayer = YES;
    self.systemBanner.layer.backgroundColor =
        [NSColor.windowBackgroundColor colorWithAlphaComponent:0.88].CGColor;
    self.systemBanner.hidden = YES;
    [cv addSubview:self.systemBanner positioned:NSWindowAbove relativeTo:nil];

    CGFloat pad = 30;
    CGFloat cw  = W - pad * 2;

    // Icon
    NSImageView *iconView = [[NSImageView alloc] initWithFrame:NSMakeRect((W - 48) / 2.0, 300, 48, 48)];
    NSImage *icon = [NSImage imageWithSystemSymbolName:@"power.circle.fill"
                              accessibilityDescription:@"Power"];
    if (icon) {
        NSImageSymbolConfiguration *cfg = [NSImageSymbolConfiguration
            configurationWithPointSize:40 weight:NSFontWeightLight];
        iconView.image = [icon imageWithSymbolConfiguration:cfg];
        iconView.contentTintColor = NSColor.tertiaryLabelColor;
        [self.systemBanner addSubview:iconView];
    }

    // Title
    self.systemTitleLabel = [NSTextField labelWithString:@"Container system is not running"];
    self.systemTitleLabel.frame     = NSMakeRect(pad, 266, cw, 22);
    self.systemTitleLabel.font      = [NSFont systemFontOfSize:15 weight:NSFontWeightSemibold];
    self.systemTitleLabel.textColor = NSColor.labelColor;
    self.systemTitleLabel.alignment = NSTextAlignmentCenter;
    [self.systemBanner addSubview:self.systemTitleLabel];

    // Body
    self.systemBodyLabel = [NSTextField wrappingLabelWithString:
        @"The container system must be started before you can pull or launch images.\n"
         "Click below to run \u201ccontainer system start\u201d."];
    self.systemBodyLabel.frame     = NSMakeRect(pad, 196, cw, 62);
    self.systemBodyLabel.font      = [NSFont systemFontOfSize:12];
    self.systemBodyLabel.textColor = NSColor.secondaryLabelColor;
    self.systemBodyLabel.alignment = NSTextAlignmentCenter;
    [self.systemBanner addSubview:self.systemBodyLabel];

    // Start button
    CGFloat sBtnW = 200;
    self.startSystemButton = [NSButton buttonWithTitle:@""
                                                target:self
                                                action:@selector(onStartSystem:)];
    self.startSystemButton.frame         = NSMakeRect((W - sBtnW) / 2.0, 154, sBtnW, 32);
    self.startSystemButton.bezelStyle    = NSBezelStyleRounded;
    self.startSystemButton.keyEquivalent = @"\r";
    [self setButton:self.startSystemButton text:@"Start Container System"];
    [self.systemBanner addSubview:self.startSystemButton];

    // Spinner next to start button
    self.startSystemSpinner = [[NSProgressIndicator alloc]
        initWithFrame:NSMakeRect((W + sBtnW) / 2.0 + 6, 161, 16, 16)];
    self.startSystemSpinner.style                = NSProgressIndicatorStyleSpinning;
    self.startSystemSpinner.controlSize          = NSControlSizeSmall;
    self.startSystemSpinner.displayedWhenStopped = NO;
    [self.systemBanner addSubview:self.startSystemSpinner];

    // Status label
    self.startSystemStatusLabel = [NSTextField labelWithString:@""];
    self.startSystemStatusLabel.frame         = NSMakeRect(pad, 126, cw, 18);
    self.startSystemStatusLabel.font          = [NSFont systemFontOfSize:11];
    self.startSystemStatusLabel.textColor     = NSColor.secondaryLabelColor;
    self.startSystemStatusLabel.alignment     = NSTextAlignmentCenter;
    self.startSystemStatusLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    [self.systemBanner addSubview:self.startSystemStatusLabel];

    NSBox *sep = [[NSBox alloc] initWithFrame:NSMakeRect(pad, 110, cw, 1)];
    sep.boxType = NSBoxSeparator;
    [self.systemBanner addSubview:sep];

    NSTextField *alreadyNote = [NSTextField labelWithString:
        @"Already started the system manually?"];
    alreadyNote.frame     = NSMakeRect(pad, 84, cw, 16);
    alreadyNote.font      = [NSFont systemFontOfSize:11];
    alreadyNote.textColor = NSColor.tertiaryLabelColor;
    alreadyNote.alignment = NSTextAlignmentCenter;
    [self.systemBanner addSubview:alreadyNote];

    self.recheckSystemButton = [NSButton buttonWithTitle:@"Re-check System"
                                                  target:self
                                                  action:@selector(onRecheckSystem:)];
    CGFloat rBtnW = 160;
    self.recheckSystemButton.frame      = NSMakeRect((W - rBtnW) / 2.0, 50, rBtnW, 26);
    self.recheckSystemButton.bezelStyle = NSBezelStyleRounded;
    self.recheckSystemButton.font       = [NSFont systemFontOfSize:12];
    [self.systemBanner addSubview:self.recheckSystemButton];
}

- (void)buildMenu {
    NSMenu *menuBar  = [[NSMenu alloc] init];
    NSMenuItem *item = [[NSMenuItem alloc] init];
    [menuBar addItem:item];
    NSApp.mainMenu = menuBar;
    NSMenu *appMenu = [[NSMenu alloc] init];
    item.submenu = appMenu;
    [appMenu addItemWithTitle:@"About Container Launcher"
                       action:@selector(showAboutPanel:)
                keyEquivalent:@""];
    [appMenu addItem:[NSMenuItem separatorItem]];
    [appMenu addItemWithTitle:@"Quit Container Launcher"
                       action:@selector(terminate:)
                keyEquivalent:@"q"];
}

- (BOOL)isContainerInstalled {
    NSFileManager *fm = NSFileManager.defaultManager;
    for (NSString *path in @[@"/usr/local/bin/container",
                              @"/opt/homebrew/bin/container",
                              @"/usr/bin/container"]) {
        if ([fm isExecutableFileAtPath:path]) return YES;
    }
    return NO;
}

- (void)checkContainerInstalled {
    BOOL installed = [self isContainerInstalled];
    self.installBanner.hidden = installed;
    [self setMainUIEnabled:installed];
    if (installed) {
        [self setStatus:@"Checking system status\u2026" isError:NO];
        [self checkContainerSystemRunning];
    }
}

- (void)checkContainerSystemRunning {
    // `container system status` exits 0 when the VM/daemon is up,
    // non-zero (or contains "stopped"/"not running") when it is not.
    [self runContainerCLI:@[@"system", @"status"]
               completion:^(BOOL success, NSString *output) {
        dispatch_async(dispatch_get_main_queue(), ^{
            // Consider the system running if the command succeeded OR if the
            // output explicitly mentions a running state.
            NSString *lower = output.lowercaseString;
            BOOL running = success
                && ![lower containsString:@"stopped"]
                && ![lower containsString:@"not running"]
                && ![lower containsString:@"shutting down"];

            self.systemBanner.hidden = running;
            [self setMainUIEnabled:running];

            if (running) {
                [self setStatus:@"Ready" isError:NO];
                [self checkImageDownloaded];
            } else {
                [self setStatus:@"Container system is not running" isError:YES];
                [self setStartSystemStatus:@"" isError:NO];
            }
        });
    }];
}

- (void)onDownloadInstaller:(id)sender {
    self.downloadButton.enabled = NO;
    self.recheckButton.enabled  = NO;
    [self.downloadSpinner startAnimation:nil];
    [self setDownloadStatus:@"Fetching latest release info\u2026" isError:NO];
    [self fetchLatestReleaseAndDownload];
}

- (void)fetchLatestReleaseAndDownload {
    NSURL *apiURL = [NSURL URLWithString:kGitHubLatestReleaseAPI];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:apiURL];
    [req setValue:@"ContainerLauncher/1.0" forHTTPHeaderField:@"User-Agent"];
    [req setValue:@"application/vnd.github+json" forHTTPHeaderField:@"Accept"];

    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithRequest:req completionHandler:^(NSData *data,
                                                           NSURLResponse *resp,
                                                           NSError *err) {
        if (err || !data) {
            [self downloadFailed:[NSString stringWithFormat:@"Could not reach GitHub: %@",
                                  err.localizedDescription ?: @"unknown error"]];
            return;
        }

        NSError *jsonErr = nil;
        NSDictionary *release = [NSJSONSerialization JSONObjectWithData:data
                                                                options:0
                                                                  error:&jsonErr];
        if (!release || jsonErr) {
            [self downloadFailed:@"Could not parse GitHub release data."];
            return;
        }

        NSString *tagName = release[@"tag_name"];
        NSArray  *assets  = release[@"assets"];

        if (![assets isKindOfClass:[NSArray class]]) {
            [self downloadFailed:@"No assets found in the latest release."];
            return;
        }

        NSURL *pkgURL = nil;
        for (NSDictionary *asset in assets) {
            NSString *name = asset[@"name"];
            if ([name hasSuffix:@".pkg"] && [name containsString:@"installer"]) {
                NSString *dlURL = asset[@"browser_download_url"];
                if (dlURL) { pkgURL = [NSURL URLWithString:dlURL]; }
                break;
            }
        }

        if (!pkgURL && tagName) {
            NSString *fallback = [NSString stringWithFormat:
                @"https://github.com/apple/container/releases/download/%@/container-%@-installer-signed.pkg",
                tagName, tagName];
            pkgURL = [NSURL URLWithString:fallback];
        }

        if (!pkgURL) {
            [self downloadFailed:@"Could not locate installer package in the latest release."];
            return;
        }

        NSString *version = tagName ?: @"latest";
        dispatch_async(dispatch_get_main_queue(), ^{
            [self setDownloadStatus:[NSString stringWithFormat:
                @"Downloading container %@\u2026", version] isError:NO];
        });
        [self downloadPkgFromURL:pkgURL version:version];
    }] resume];
}

- (void)downloadPkgFromURL:(NSURL *)pkgURL version:(NSString *)version {
    NSString *fileName = [NSString stringWithFormat:@"container-%@-installer.pkg", version];
    NSURL    *tmpURL   = [[NSURL fileURLWithPath:NSTemporaryDirectory()]
                           URLByAppendingPathComponent:fileName];

    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDownloadTask *task =
        [session downloadTaskWithURL:pkgURL
                   completionHandler:^(NSURL *loc, NSURLResponse *resp, NSError *err) {
        if (err || !loc) {
            [self downloadFailed:[NSString stringWithFormat:@"Download failed: %@",
                                  err.localizedDescription ?: @"unknown error"]];
            return;
        }

        NSError *moveErr = nil;
        [[NSFileManager defaultManager] removeItemAtURL:tmpURL error:nil];
        [[NSFileManager defaultManager] moveItemAtURL:loc toURL:tmpURL error:&moveErr];

        if (moveErr) {
            [self downloadFailed:[NSString stringWithFormat:@"Could not save installer: %@",
                                  moveErr.localizedDescription]];
            return;
        }

        dispatch_async(dispatch_get_main_queue(), ^{
            [self.downloadSpinner stopAnimation:nil];
            [self setDownloadStatus:@"Installer downloaded \u2014 opening\u2026" isError:NO];

            [[NSWorkspace sharedWorkspace] openURL:tmpURL];

            self.installBodyLabel.stringValue =
                @"The installer has opened. Follow the on-screen prompts \u2014 "
                 "the app will continue automatically once Container is installed.";
            self.downloadButton.enabled = YES;
            self.recheckButton.enabled  = YES;

            [self startInstallWatcher];
        });
    }];
    [task resume];
}

- (void)downloadFailed:(NSString *)reason {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.downloadSpinner stopAnimation:nil];
        self.downloadButton.enabled = YES;
        self.recheckButton.enabled  = YES;
        [self setDownloadStatus:reason isError:YES];
    });
}

- (void)startInstallWatcher {
    [self stopInstallWatcher];
    self.installCheckTimer =
        [NSTimer scheduledTimerWithTimeInterval:2.0
                                         target:self
                                       selector:@selector(installWatcherTick:)
                                       userInfo:nil
                                        repeats:YES];
}

- (void)stopInstallWatcher {
    [self.installCheckTimer invalidate];
    self.installCheckTimer = nil;
}

- (void)installWatcherTick:(NSTimer *)timer {
    if (![self isContainerInstalled]) return;

    [self stopInstallWatcher];
    [self setDownloadStatus:@"" isError:NO];

    [self setStatus:@"Ready." isError:NO];
    [NSAnimationContext runAnimationGroup:^(NSAnimationContext *ctx) {
        ctx.duration = 0.25;
        self.installBanner.animator.alphaValue = 0.0;
    } completionHandler:^{
        self.installBanner.hidden = YES;
        self.installBanner.alphaValue = 1.0;
        [self setMainUIEnabled:YES];
        [self checkContainerSystemRunning];
    }];
}

- (void)onRecheckInstall:(id)sender {
    [self checkContainerInstalled];
    if ([self isContainerInstalled]) {
        [self stopInstallWatcher];
    } else {
        [self setDownloadStatus:@"Container still not found. Complete the installer and try again." isError:YES];
    }
}

- (void)onStartSystem:(id)sender {
    self.startSystemButton.enabled   = NO;
    self.recheckSystemButton.enabled = NO;
    [self.startSystemSpinner startAnimation:nil];
    [self setStartSystemStatus:@"Starting container system\u2026 (this may take a moment)" isError:NO];

    [self runContainerCLI:@[@"system", @"start"]
               completion:^(BOOL success, NSString *output) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.startSystemSpinner stopAnimation:nil];
            self.startSystemButton.enabled   = YES;
            self.recheckSystemButton.enabled = YES;

            if (success) {
                [self setStartSystemStatus:@"System started \u2014 verifying\u2026" isError:NO];
                // Give the daemon a moment to settle, then re-check.
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
                               dispatch_get_main_queue(), ^{
                    [self checkContainerSystemRunning];
                });
            } else {
                NSString *msg = output.length
                    ? [NSString stringWithFormat:@"Failed to start: %@", output]
                    : @"Failed to start the container system. Try running \u201ccontainer system start\u201d in Terminal.";
                [self setStartSystemStatus:msg isError:YES];
            }
        });
    }];
}

- (void)onRecheckSystem:(id)sender {
    [self setStartSystemStatus:@"Checking\u2026" isError:NO];
    [self checkContainerSystemRunning];
}

- (void)onImageChanged:(id)sender {
    [self checkImageDownloaded];
}
- (void)onShellChanged:(id)sender  { [self updateShellDescription]; }

- (void)onToggleCustomImage:(id)sender {
    self.usingCustomImage = (self.customImageToggle.state == NSControlStateValueOn);
    self.imagePopup.hidden       = self.usingCustomImage;
    self.customImageField.hidden = !self.usingCustomImage;
    if (self.usingCustomImage) [self.window makeFirstResponder:self.customImageField];
    [self checkImageDownloaded];
}

- (void)onLaunch:(id)sender {
    NSString *image = [self resolvedImageName];
    NSString *shell = [self resolvedShellPath];
    if (!image || image.length == 0) {
        [self setStatus:@"Choose an image before launching." isError:YES]; return;
    }
    [self setStatus:[NSString stringWithFormat:@"Opening terminal with %@\u2026", image] isError:NO];

    NSString *cliPath = [self containerCLIPath];

    // The shell path goes directly after the image name.
    // Apple's container CLI does NOT support the `--` end-of-flags delimiter
    // that Docker uses; passing it causes "failed to find target executable --".
    NSString *cmd = [NSString stringWithFormat:@"%@ run --interactive --tty %@ %@ -l",
                     cliPath, image, shell];

    // Escape backslashes first, then double-quotes, for safe embedding in an
    // AppleScript string literal. The original code only escaped quotes, which
    // would corrupt any path containing a backslash and is the root cause of
    // the zsh launch failure on some system configurations.
    NSString *escaped = [cmd stringByReplacingOccurrencesOfString:@"\\" withString:@"\\\\"];
    escaped = [escaped stringByReplacingOccurrencesOfString:@"\"" withString:@"\\\""];
    NSString *script  = [NSString stringWithFormat:
        @"tell application \"Terminal\"\n  activate\n  do script \"%@\"\nend tell", escaped];

    NSDictionary *errInfo = nil;
    NSAppleScript *as = [[NSAppleScript alloc] initWithSource:script];
    [as executeAndReturnError:&errInfo];

    if (errInfo) {
        [self setStatus:[NSString stringWithFormat:@"Couldn\u2019t open Terminal \u2014 %@",
                         errInfo[NSAppleScriptErrorMessage]] isError:YES];
    } else {
        [self setStatus:[NSString stringWithFormat:@"Terminal opened with %@", image] isError:NO];
    }
}

- (void)onPull:(id)sender {
    NSString *image = [self resolvedImageName];
    if (!image || image.length == 0) {
        [self setStatus:@"Choose an image to download." isError:YES]; return;
    }
    self.pullButton.enabled = self.launchButton.enabled = NO;
    [self.spinner startAnimation:nil];
    [self setStatus:[NSString stringWithFormat:@"Downloading %@\u2026", image] isError:NO];

    [self runContainerCLI:@[@"image", @"pull", image]
               completion:^(BOOL success, NSString *output) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.spinner stopAnimation:nil];
            if (success) {
                [self setStatus:[NSString stringWithFormat:@"%@ ready to launch", image] isError:NO];
            } else {
                [self setStatus:[NSString stringWithFormat:@"Download failed \u2014 check your connection (%@)",
                                 output.length ? output : @"unknown error"] isError:YES];
            }
            [self checkImageDownloaded];
        });
    }];
}


- (void)checkImageDownloaded {
    NSString *image = [self resolvedImageName];

    if (self.usingCustomImage) {
        self.pullButton.enabled   = YES;
        self.launchButton.enabled = YES;
        return;
    }

    self.pullButton.enabled   = NO;
    self.launchButton.enabled = NO;

    [self runContainerCLI:@[@"image", @"list", @"--quiet"]
               completion:^(BOOL success, NSString *output) {
        dispatch_async(dispatch_get_main_queue(), ^{
            BOOL present = NO;
            if (success) {
                for (NSString *rawLine in [output componentsSeparatedByString:@"\n"]) {
                    NSString *line = [rawLine stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
                    if (line.length == 0) continue;
                    if ([line isEqualToString:image] || [line hasSuffix:[@"/" stringByAppendingString:image]]) {
                        present = YES;
                        break;
                    }
                }
            }
            self.pullButton.enabled   = !present;
            self.launchButton.enabled =  present;
        });
    }];
}

- (void)updateShellDescription {
    NSString *sel = self.shellPopup.selectedItem.title;
    self.shellDescLabel.stringValue = shellDescriptions()[sel] ?: @"";
}

- (NSString *)resolvedImageName {
    if (self.usingCustomImage) return self.customImageField.stringValue;
    NSString *friendly = self.imagePopup.selectedItem.title;
    return imageIDMap()[friendly] ?: friendly;
}

- (NSString *)resolvedShellPath {
    return shellIDMap()[self.shellPopup.selectedItem.title] ?: @"/bin/bash";
}

- (void)runContainerCLI:(NSArray<NSString *> *)args
            completion:(void(^)(BOOL success, NSString *output))completion {
    NSString *cliPath = [self containerCLIPath];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSTask *task        = [[NSTask alloc] init];
        task.launchPath     = cliPath;
        task.arguments      = args;
        NSPipe *outPipe     = [NSPipe pipe];
        NSPipe *errPipe     = [NSPipe pipe];
        task.standardOutput = outPipe;
        task.standardError  = errPipe;
        @try { [task launch]; [task waitUntilExit]; }
        @catch (NSException *e) { if (completion) completion(NO, e.reason); return; }
        NSString *out = [[NSString alloc] initWithData:outPipe.fileHandleForReading.readDataToEndOfFile
                                              encoding:NSUTF8StringEncoding] ?: @"";
        NSString *err = [[NSString alloc] initWithData:errPipe.fileHandleForReading.readDataToEndOfFile
                                              encoding:NSUTF8StringEncoding] ?: @"";
        BOOL ok = (task.terminationStatus == 0);
        if (completion) completion(ok, ok ? out : (err.length ? err : out));
    });
}

- (NSString *)containerCLIPath {
    NSFileManager *fm = NSFileManager.defaultManager;
    for (NSString *path in @[@"/usr/local/bin/container",
                              @"/opt/homebrew/bin/container",
                              @"/usr/bin/container"]) {
        if ([fm isExecutableFileAtPath:path]) return path;
    }
    return @"/usr/local/bin/container";
}

- (void)setStatus:(NSString *)msg isError:(BOOL)error {
    self.statusLabel.stringValue = msg ?: @"";
    self.statusLabel.textColor   = error ? NSColor.systemRedColor : NSColor.secondaryLabelColor;
}

- (void)setDownloadStatus:(NSString *)msg isError:(BOOL)error {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.downloadStatusLabel.stringValue = msg ?: @"";
        self.downloadStatusLabel.textColor   =
            error ? NSColor.systemRedColor : NSColor.secondaryLabelColor;
    });
}

- (void)setStartSystemStatus:(NSString *)msg isError:(BOOL)error {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.startSystemStatusLabel.stringValue = msg ?: @"";
        self.startSystemStatusLabel.textColor   =
            error ? NSColor.systemRedColor : NSColor.secondaryLabelColor;
    });
}

- (void)setMainUIEnabled:(BOOL)enabled {
    for (NSView *v in @[self.imagePopup, self.shellPopup, self.customImageField,
                         self.customImageToggle, self.pullButton, self.launchButton]) {
        if ([v respondsToSelector:@selector(setEnabled:)]) {
            [(NSControl *)v setEnabled:enabled];
        }
    }
}

- (void)setButton:(NSButton *)button text:(NSString *)text {
    button.title = text;
    button.font  = [NSFont systemFontOfSize:13];
}

- (void)showAboutPanel:(id)sender {
    // Build a custom About window that is centered and modal.
    NSRect frame = NSMakeRect(0, 0, 340, 220);
    NSWindowStyleMask style = NSWindowStyleMaskTitled
                            | NSWindowStyleMaskClosable;
    NSWindow *aboutWin = [[NSWindow alloc] initWithContentRect:frame
                                                     styleMask:style
                                                       backing:NSBackingStoreBuffered
                                                         defer:NO];
    aboutWin.title             = @"About Container Launcher";
    aboutWin.releasedWhenClosed = YES;

    NSVisualEffectView *vev = [[NSVisualEffectView alloc] initWithFrame:frame];
    vev.material     = NSVisualEffectMaterialSidebar;
    vev.blendingMode = NSVisualEffectBlendingModeBehindWindow;
    vev.state        = NSVisualEffectStateActive;
    aboutWin.contentView = vev;

    CGFloat W = 340;

    // App icon
    NSImageView *iconView = [[NSImageView alloc] initWithFrame:NSMakeRect((W - 80) / 2.0, 135, 80, 80)];
    iconView.image = [NSImage imageNamed:@"AppIcon"];
    iconView.imageScaling = NSImageScaleProportionallyUpOrDown;
    [vev addSubview:iconView];

    // App name
    NSTextField *nameLabel = [NSTextField labelWithString:@"Container Launcher"];
    nameLabel.frame     = NSMakeRect(0, 116, W, 22);
    nameLabel.font      = [NSFont systemFontOfSize:16 weight:NSFontWeightSemibold];
    nameLabel.textColor = NSColor.labelColor;
    nameLabel.alignment = NSTextAlignmentCenter;
    [vev addSubview:nameLabel];

    // Version
    NSString *version = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"]
                        ?: @"1.0";
    NSTextField *versionLabel = [NSTextField labelWithString:
        [NSString stringWithFormat:@"Version %@", version]];
    versionLabel.frame     = NSMakeRect(0, 96, W, 16);
    versionLabel.font      = [NSFont systemFontOfSize:12];
    versionLabel.textColor = NSColor.secondaryLabelColor;
    versionLabel.alignment = NSTextAlignmentCenter;
    [vev addSubview:versionLabel];

    NSBox *sep = [[NSBox alloc] initWithFrame:NSMakeRect(30, 76, W - 60, 1)];
    sep.boxType = NSBoxSeparator;
    [vev addSubview:sep];

    // Copyright
    NSTextField *copyrightLabel = [NSTextField labelWithString:
        @"\u00A9 2026 Landon J. Smith"];
    copyrightLabel.frame     = NSMakeRect(0, 52, W, 16);
    copyrightLabel.font      = [NSFont systemFontOfSize:12];
    copyrightLabel.textColor = NSColor.secondaryLabelColor;
    copyrightLabel.alignment = NSTextAlignmentCenter;
    [vev addSubview:copyrightLabel];

    // Tagline
    NSTextField *tagLabel = [NSTextField labelWithString:@"A GUI launcher for Apple\u2019s container CLI."];
    tagLabel.frame     = NSMakeRect(0, 32, W, 14);
    tagLabel.font      = [NSFont systemFontOfSize:11];
    tagLabel.textColor = NSColor.tertiaryLabelColor;
    tagLabel.alignment = NSTextAlignmentCenter;
    [vev addSubview:tagLabel];

    [aboutWin center];
    [aboutWin makeKeyAndOrderFront:nil];
}

@end
