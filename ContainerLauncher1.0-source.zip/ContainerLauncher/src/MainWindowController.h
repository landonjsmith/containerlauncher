#pragma once
#import <Cocoa/Cocoa.h>

// All UI properties are declared privately in the .mm file's class extension.
// The public interface only exposes what external callers need (currently nothing beyond init).
@interface MainWindowController : NSWindowController

- (instancetype)init;

@end
