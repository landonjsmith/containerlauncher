# ContainerLauncher

A minimal macOS GUI launcher for Apple's `container` CLI.

## What it does

- Dropdown of common images (ubuntu, debian, alpine, fedora, etc.) — editable for any custom image
- Shell field (defaults to `/bin/bash`)
- **Launch Terminal** — runs `container run -it <image> <shell>` in a new Terminal.app window
- **Pull** — pulls the selected image in the background, with a spinner

## Requirements

- Apple Silicon Mac (arm64)
- macOS 13.0+
- Xcode Command Line Tools: `xcode-select --install`
- CMake: `brew install cmake`
- Apple's `container` CLI installed at `/usr/local/bin/container` or `/opt/homebrew/bin/container`

## Build

```bash
cd ContainerLauncher
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j$(sysctl -n hw.logicalcpu)
```

The `.app` bundle will be at:
```
build/ContainerLauncher.app
```

Copy it to `/Applications` if you want:
```bash
cp -r build/ContainerLauncher.app /Applications/
```

## Notes

- The app uses `NSAppleScript` to tell Terminal.app to open a new window and run
  the container command. macOS may prompt you to grant automation permissions the
  first time — click OK.
- The `container` binary must already be in one of the checked paths. If yours is
  elsewhere, edit `containerCLIPath` in `MainWindowController.mm`.
- The `container system start` service must be running before you launch a container.
  You can start it from a regular terminal: `container system start`
